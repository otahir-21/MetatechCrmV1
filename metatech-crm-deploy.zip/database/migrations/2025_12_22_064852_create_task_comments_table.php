<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('task_comments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('task_id')->constrained('tasks')->onDelete('cascade');
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->text('comment'); // Rich text comment (like Notion)
            $table->foreignId('parent_comment_id')->nullable()->constrained('task_comments')->onDelete('cascade'); // For threaded comments
            $table->json('mentions')->nullable(); // Array of mentioned user IDs (like Notion @mentions)
            $table->json('attachments')->nullable(); // Array of file attachments
            $table->timestamps();
            
            $table->index('task_id');
            $table->index('user_id');
            $table->index('parent_comment_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('task_comments');
    }
};
