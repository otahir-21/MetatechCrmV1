<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'first_name',
        'last_name',
        'company_name',
        'subdomain',
        'is_metatech_employee',
        'department',
        'designation',
        'joined_date',
        'status',
        'status_reason',
        'blocked_at',
        'blocked_by',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'blocked_at' => 'datetime',
            'is_metatech_employee' => 'boolean',
            'joined_date' => 'date',
        ];
    }

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [
            'role' => $this->role,
            'email' => $this->email,
            'subdomain' => $this->subdomain,
            'company_name' => $this->company_name,
            'is_metatech_employee' => $this->is_metatech_employee,
        ];
    }

    /**
     * Check if user is super admin.
     *
     * @return bool
     */
    public function isSuperAdmin(): bool
    {
        return $this->role === 'super_admin';
    }

    /**
     * Check if user is company super admin (has company_name and subdomain).
     *
     * @return bool
     */
    public function isCompanySuperAdmin(): bool
    {
        return $this->role === 'super_admin' 
            && $this->company_name !== null 
            && $this->subdomain !== null
            && !$this->is_metatech_employee;
    }

    /**
     * Check if user is product owner (System Super Admin without company).
     *
     * @return bool
     */
    public function isProductOwner(): bool
    {
        return $this->role === 'super_admin' 
            && $this->company_name === null 
            && $this->subdomain === null
            && !$this->is_metatech_employee;
    }

    /**
     * Check if user is internal super admin (Metatech employee with super_admin role).
     *
     * @return bool
     */
    public function isInternalSuperAdmin(): bool
    {
        return $this->role === 'super_admin' && (bool) $this->is_metatech_employee;
    }

    /**
     * Check if user is internal admin (Metatech employee with admin role).
     *
     * @return bool
     */
    public function isInternalAdmin(): bool
    {
        return $this->role === 'admin' && (bool) $this->is_metatech_employee;
    }

    /**
     * Check if user is an internal Metatech employee (any role).
     *
     * @return bool
     */
    public function isInternalEmployee(): bool
    {
        return $this->is_metatech_employee === true;
    }

    /**
     * Check if user can manage internal employees (Product Owner, Internal Super Admin, or Internal Admin).
     *
     * @return bool
     */
    public function canManageInternalEmployees(): bool
    {
        return $this->isProductOwner() || $this->isInternalSuperAdmin() || $this->isInternalAdmin();
    }

    /**
     * Check if user can view all projects (Super Admin or Admin).
     *
     * @return bool
     */
    public function canViewAllProjects(): bool
    {
        if (!$this->is_metatech_employee) {
            return false;
        }
        return $this->role === 'super_admin' || $this->role === 'admin';
    }

    /**
     * Check if user can create projects.
     *
     * @return bool
     */
    public function canCreateProjects(): bool
    {
        if (!$this->is_metatech_employee) {
            return false;
        }
        // All internal employees can create projects
        return true;
    }

    /**
     * Check if user can manage all users (Super Admin only).
     *
     * @return bool
     */
    public function canManageAllUsers(): bool
    {
        if (!$this->is_metatech_employee) {
            return false;
        }
        return $this->role === 'super_admin';
    }

    /**
     * Check if user can manage roles (Super Admin only).
     *
     * @return bool
     */
    public function canManageRoles(): bool
    {
        if (!$this->is_metatech_employee) {
            return false;
        }
        return $this->role === 'super_admin';
    }

    /**
     * Check if user can access system settings (Super Admin only).
     *
     * @return bool
     */
    public function canManageSettings(): bool
    {
        if (!$this->is_metatech_employee) {
            return false;
        }
        return $this->role === 'super_admin';
    }

    public function tasks()
    {
        return $this->hasMany(\App\Models\Task::class, 'assigned_to');
    }

    public function createdTasks()
    {
        return $this->hasMany(\App\Models\Task::class, 'created_by');
    }
}
